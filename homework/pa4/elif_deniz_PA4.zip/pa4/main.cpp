#include <iostream>
#include "SchoolManagerSystem.hpp"
using namespace PA4;
int main() {
    SchoolManagerSystem system;
    system.run();
    return 0;
}
